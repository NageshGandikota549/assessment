﻿namespace Matchbook.Model
{
    public enum Side { Buy, Sell }
}
