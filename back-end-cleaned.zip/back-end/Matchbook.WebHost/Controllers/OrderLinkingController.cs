using Matchbook.Db;
using Matchbook.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace Matchbook.WebHost.Controllers
{
    public class LinkOrderModel
    {
        public string LinkName { get; set; } 
        public int[] orderIds { get; set; }

    }

    [ApiController]
    [Route("[controller]")]
    public class OrderLinkingCOntroller : ControllerBase
    {
        private readonly MatchbookDbContext dbContext;
        public OrderLinkingCOntroller(MatchbookDbContext dbContext)
        {
            this.dbContext = dbContext;
        }           


        [HttpPost]
        public async Task<ActionResult> Post(LinkOrderModel args)
        {

            var linkNameAlreadyExists = dbContext.OrderLinks.Any(x=>x.Name.ToLower() == args.LinkName.ToLower());

            if (linkNameAlreadyExists)
            {
                return StatusCode(StatusCodes.Status400BadRequest, $"link name '{args.LinkName}' Already Exists. plse give different name");
            }

            var orders = await dbContext.Orders.Where(o => args.orderIds.Any(x => x == o.Id)).ToListAsync();

         
            var alreadyLinkedOrders = orders.Where(x => x.LinkId != null);

            if (alreadyLinkedOrders.Count() > 0)
            {
                return StatusCode(StatusCodes.Status400BadRequest, $"orders Ids {String.Join(",",alreadyLinkedOrders.Select(x => x.Id).ToArray())} are already part of onother link");
            }

            var groupedorders = orders.GroupBy(o => new { o.ProductSymbol, o.SubAccount });
            if (groupedorders.Count() > 1)
            {
                return StatusCode(StatusCodes.Status400BadRequest, "orders not having same product symbol and sub account");
            }


            orders = orders.Select(x=> { x.LinkName = args.LinkName; return x; }).ToList();

            var newlink = new OrderLink { LinkedOrders = orders ,Name = args.LinkName};

            dbContext.OrderLinks.Add(newlink);

            dbContext.SaveChanges();

            return StatusCode(StatusCodes.Status201Created, newlink.Id);

        }

    }
}